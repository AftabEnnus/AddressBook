/*
Name : Shaikh Aftab Ennus
Date : 29/09/2024
Description : AddressBook project(main file)
Contents : all menu info 
*/
#include<stdio.h>
#include"contact.h"
int main() {
    AddressBook addressBook;
    loadAndStoreContacts(&addressBook);  // Load contacts from file

    int choice;

    do {
        printf("\nAddress Book Menu:\n");
        printf("1. Create Contact\n");
        printf("2. List Contacts\n");
        printf("3. Search Contact\n");
        printf("4. Edit Contact\n");
        printf("5. Delete Contact\n");
        printf("6. Save & Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar();

        switch (choice) {
            case 1:
                createContact(&addressBook);
                saveContacts(&addressBook);  // Save after creating a contact
                break;
            case 2:
                listContacts(&addressBook);
                break;
            case 3:
                searchContact(&addressBook);
                break;
            case 4:
                editContact(&addressBook);
                saveContacts(&addressBook);  // Save after editing
                break;
            case 5:
                deleteContact(&addressBook);
                saveContacts(&addressBook);  // Save after deleting
                break;
            case 6:
                saveContacts(&addressBook);  // Save before exit
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 6);

    return 0;
}

