/*
Name : Shaikh Aftab Ennus
date : 29/09/2024
Description : AddressBook project (Contact file)
content : validation and user operations
*/
#include "contact.h"
#include<string.h>
#include <stdio.h>
#include <ctype.h>
#define RESET   "\033[0m" // this all are for coloring purpose
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
int isValidName(const char* name) {
	for (int i = 0; name[i] != '\0'; i++) {
		if (!isalpha(name[i]) && name[i]!=' '){ // it will check the string should contain only alphabets
			return 0;
		}
	}
	return 1;
}
int isValidPhone(const char* phone, AddressBook* addressBook) {
	if (strlen(phone) != 10) return 0;
	for (int i = 0; i < 10; i++) {
		if (!isdigit(phone[i])) return 0;//it will check string contain all digit(10)
	}

	for (int i = 0; i < addressBook->contactCount; i++) {
		if (strcmp(phone, addressBook->contacts[i].phone) == 0) {//it will check phone number in file
			return 0;
		}
	}
	return 1;
}
int isValidEmail(const char* email, AddressBook* addressBook) {
    const char* at = strchr(email, '@');
    const char* dot = strrchr(email, '.');

    if (!at || at == email || !dot || at >= dot || strcmp(dot, ".com") != 0) {// it will check vaild email presence of @,.,.com
        return 0;
    }

    const char* temp = strstr(at, ".com");
    if (temp != dot) {
        return 0;
    }

    for (int i = 0; i < addressBook->contactCount; i++) { // it will check email in file 
        if (strcmp(email, addressBook->contacts[i].email) == 0) {
            return 0;
        }
    }

    return 1;
}

void loadAndStoreContacts(AddressBook* addressBook) {// it will load & store data from file to array of structure
	FILE *file = fopen("data.txt", "r");
	if (!file) {
		printf(RED"No existing contacts found, starting with an empty address book.\n"RESET);
		return;
	}
	addressBook->contactCount = 0;
	while (fscanf(file, "%49[^,],%19[^,],%49[^\n]\n",
				addressBook->contacts[addressBook->contactCount].name,
				addressBook->contacts[addressBook->contactCount].phone,
				addressBook->contacts[addressBook->contactCount].email) != EOF) {
		addressBook->contactCount++;
	}
	fclose(file);
}
void saveContacts(AddressBook* addressBook) {//it will save edited and new contact in file
	FILE *file = fopen("data.txt", "w");
	if (!file) {
		printf(RED"Error saving contacts.\n"RESET);
		return;
	}
	for (int i = 0; i < addressBook->contactCount; i++) {
		fprintf(file, "%s,%s,%s\n",
				addressBook->contacts[i].name,
				addressBook->contacts[i].phone,
				addressBook->contacts[i].email);
	}
	fclose(file);
}
void listContacts(AddressBook *addressBook) {// just for display content of files on screen or display
	printf(GREEN"+----------------------------------------------------------------------+\n"RESET);
	printf(GREEN"|                          DIGITAL ADDRESSBOOK                         |\n"RESET);
	printf(GREEN"+----------------------------------------------------------------------+\n"RESET);
	printf(GREEN"| %-20s | %-13s | %-29s |\n"RESET, "Name", "Phone", "Email");
	printf(GREEN"+----------------------------------------------------------------------+\n"RESET);
	for (int i = 0; i < addressBook->contactCount; i++) {
		printf(GREEN"| %-20s | %-13s | %-29s |\n"RESET,
				addressBook->contacts[i].name,
				addressBook->contacts[i].phone,
				addressBook->contacts[i].email);
		printf(GREEN"+----------------------------------------------------------------------+\n"RESET);
	}
	if (addressBook->contactCount == 0) {
		printf(RED"| %-68s |\n"RESET, "No contacts available");
		printf(GREEN"+----------------------------------------------------------------------+\n"RESET);
	}
}
void initialize(AddressBook *addressBook)//it will initialize the contactcount of addressbook
{
	addressBook->contactCount=0;
	for(int i=0;i<MAX_CONTACTS;i++)
	{
		strcpy(addressBook->contacts[i].name," ");
		strcpy(addressBook->contacts[i].phone," ");
		strcpy(addressBook->contacts[i].email," ");
	}
}
void createContact(AddressBook *addressBook) {
	if (addressBook->contactCount >= MAX_CONTACTS) {
		printf("Address book is full. Cannot add more contacts.\n");
		return;
	}
	Contact newContact;
	int valid;   
	do {
		printf("Enter Name: ");
		scanf("%49[^\n]", newContact.name);
		getchar();  
		valid = isValidName(newContact.name);
		if (!valid) {
			printf(RED"Invalid name. Please use only alphabetic characters and spaces.\n"RESET);
		}
	} while (!valid);//it will run until user enter valid info
	do {
		printf("Enter Phone: ");
		scanf("%14s", newContact.phone);
		getchar(); 
		valid = isValidPhone(newContact.phone, addressBook);
		if (!valid) {
			printf(RED"Invalid phone number. It must be exactly 10 digits and unique.\n"RESET);
		}
	} while (!valid);// it will run until user enter valid info

	do {
		printf("Enter Email: ");
		scanf("%49s", newContact.email);
		getchar();  
		valid = isValidEmail(newContact.email, addressBook);
		if (!valid) {
			printf(RED"Invalid email. It must contain '@', end with '.com', and be unique.\n"RESET);
		}
	} while (!valid);

	addressBook->contacts[addressBook->contactCount++] = newContact;// increase contactcount
	printf(GREEN"Contact added successfully!\n"RESET);
}

void searchContact(AddressBook *addressBook)
{
    int choice;
    char str_cpy[50];
    char phone_cpy[50];
    printf("Please select from below options:\n1. Search by Name\n2. Search by Mobile Number\n");
    scanf("%d", &choice);
    getchar(); 

    switch(choice)
    {
        case 1:
        {
            printf("Enter Name (or prefix): ");
            scanf("%49[^\n]", str_cpy);
            getchar();

            for (int i = 0; str_cpy[i]; i++) {
                str_cpy[i] = tolower(str_cpy[i]);
            }

            int found = 0;
            int matchIndexes[addressBook->contactCount];
            int matchCount = 0;

            for (int i = 0; i < addressBook->contactCount; i++) {
                char nameCopy[50];
                strcpy(nameCopy, addressBook->contacts[i].name);// it will copy founded name in structure into new string

                for (int j = 0; nameCopy[j]; j++) {
                    nameCopy[j] = tolower(nameCopy[j]);
                }

                if (strstr(nameCopy, str_cpy) == nameCopy) {//if entered string and founded strings are equal then it will print choice
                    found = 1;
                    matchIndexes[matchCount++] = i; 
                    printf("%d. %s\n", matchCount, addressBook->contacts[i].name);
                }
            }

            if (!found) {
                printf(RED"No contact found with the name or prefix '%s'\n"RESET, str_cpy);
            } else if (matchCount == 1) {// display all matched data
                int idx = matchIndexes[0];
                printf("Name: %s\n", addressBook->contacts[idx].name);
                printf("Phone: %s\n", addressBook->contacts[idx].phone);
                printf("Email: %s\n", addressBook->contacts[idx].email);
            } else {
                int selected;
                printf("Enter the number of the contact you want to view: ");
                scanf("%d", &selected);// for user inputi
                getchar(); 

                if (selected > 0 && selected <= matchCount) {//check valid user input
                    int idx = matchIndexes[selected - 1];
                    printf("Name: %s\n", addressBook->contacts[idx].name);
                    printf("Phone: %s\n", addressBook->contacts[idx].phone);
                    printf("Email: %s\n", addressBook->contacts[idx].email);
                } else {
                    printf(RED"Invalid selection.\n"RESET);
                }
            }
            break;
        }
        case 2:
        {
            printf("Enter Mobile number: ");
            scanf("%11s", phone_cpy);// for user input
            getchar();

            int found = 0;
            for (int i = 0; i < addressBook->contactCount; i++) {
                if (!strcmp(phone_cpy, addressBook->contacts[i].phone)) {// for valid input
                    found = 1;
                    printf("Name: %s\n", addressBook->contacts[i].name);
                    printf("Phone: %s\n", addressBook->contacts[i].phone);
                    printf("Email: %s\n", addressBook->contacts[i].email);
                }
            }
            if (!found) {
                printf(RED"No contact found with this Mobile number %s\n"RESET, phone_cpy);
            }
            break;
        }
        default:
            printf(RED"Invalid input....\n"RESET);
    }
}

void editContact(AddressBook *addressBook) {
	char searchName[50];
	int found = 0;
	do {
		printf("Enter the name or initial letters of the contact you want to edit: ");
		scanf("%49[^\n]", searchName);
		getchar();

		if (!isValidName(searchName)) {
			printf(RED"Invalid input. Please enter a valid name or initials.\n"RESET);
		}
	} while (!isValidName(searchName));//it will run until valid input

	int foundIndices[MAX_CONTACTS];
	int foundCount = 0;

	for (int i = 0; i < addressBook->contactCount; i++) {//it will check all content of file
		if (strncasecmp(searchName, addressBook->contacts[i].name, strlen(searchName)) == 0) {
			foundIndices[foundCount++] = i;
			printf("%d. Name: %s, Phone: %s, Email: %s\n", foundCount,
					addressBook->contacts[i].name,
					addressBook->contacts[i].phone,
					addressBook->contacts[i].email);
		}
	}
	if (foundCount == 0) {
		printf(RED"No contacts found starting with: %s\n"RESET, searchName);
		return;
	}
	int index;

	if (foundCount == 1) {
		index = foundIndices[0];
		printf("Only one contact found. Proceeding to edit...\n");
	} else {
		int choice;
		do {
			printf("Enter the number of the contact you want to edit (1 to %d): ", foundCount);
			scanf("%d", &choice);
			getchar();

			if (choice < 1 || choice > foundCount) {
				printf(RED"Invalid selection. Please enter a number between 1 and %d.\n"RESET, foundCount);
			}
		} while (choice < 1 || choice > foundCount);// for valid user input

		index = foundIndices[choice - 1];
	}
	int editChoice;
	do {
		printf("\nWhat do you want to edit?\n");
		printf("1. Name\n");
		printf("2. Phone\n");
		printf("3. Email\n");
		printf("Enter your choice: ");
		scanf("%d", &editChoice);
		getchar();
		if (editChoice < 1 || editChoice > 3) {
			printf(RED"Invalid option. Please enter a valid option (1-3).\n"RESET);
		}// for legal edit option
	} while (editChoice < 1 || editChoice > 3);
	switch (editChoice) {
		case 1: {
				char newName[50];
				int valid = 0;
				do {
					printf("Enter the new name: ");
					scanf("%49[^\n]", newName);
					getchar();
					valid = isValidName(newName);// it will validate name
					if (!valid) {
						printf(RED"Invalid name. Please enter only alphabetic characters.\n"RESET);
					}
				} while (!valid);

				strcpy(addressBook->contacts[index].name, newName);// update entered data into structure and then into file
				printf(GREEN"Name updated successfully!\n"RESET);
				break;
			}
		case 2: {
				char newPhone[15];
				int valid = 0;
				do {
					printf("Enter the new phone number (10 digits): ");
					scanf("%14s", newPhone);
					getchar();
					valid = isValidPhone(newPhone, addressBook);// it will validate phone
					if (!valid) {
						printf(RED"Invalid phone number. Please ensure it's 10 digits and unique.\n"RESET);
					}
				} while (!valid);

				strcpy(addressBook->contacts[index].phone, newPhone);// update entered data into structure and then into file
				printf(GREEN"Phone number updated successfully!\n"RESET);
				break;
			}
		case 3: {
				char newEmail[50];
				int valid = 0;
				do {
					printf("Enter the new email (e.g., example@domain.com): ");
					scanf("%49s", newEmail);
					getchar();
					valid = isValidEmail(newEmail, addressBook);// it will validate email
					if (!valid) {
						printf(RED"Invalid email format. It must contain '@' and end with '.com', and be unique.\n"RESET);
					}
				} while (!valid);

				strcpy(addressBook->contacts[index].email, newEmail);// update entered data into structure and then into file
				printf(GREEN"Email updated successfully!\n"RESET);
				break;
			}

		default:
			printf(RED"Invalid option.\n"RESET);
			break;
	}
}
void deleteContact(AddressBook *addressBook) {
	char searchName[50];
	int foundCount = 0;
	do {
		printf("Enter the name or initial letters of the contact you want to delete: ");
		scanf("%49[^\n]", searchName);
		getchar();

		if (!isValidName(searchName)) {// validate entered name
			printf(RED"Invalid input. Please enter a valid name or initials.\n"RESET);
		}
	} while (!isValidName(searchName));

	int foundIndices[MAX_CONTACTS];

	for (int i = 0; i < addressBook->contactCount; i++) {
		if (strncasecmp(searchName, addressBook->contacts[i].name, strlen(searchName)) == 0) {
			foundIndices[foundCount++] = i;
			printf("%d. Name: %s, Phone: %s, Email: %s\n", foundCount,
					addressBook->contacts[i].name,
					addressBook->contacts[i].phone,
					addressBook->contacts[i].email);
		}
	}
	if (foundCount == 0) {
		printf(RED"No contacts found starting with: %s\n"RESET, searchName);
		return;
	}

	int index;
	if (foundCount == 1) {
		index = foundIndices[0];
		printf("Only one contact found. Proceeding to delete...\n");
	} else {
		int choice;
		do {
			printf("Enter the number of the contact you want to delete (1 to %d): ", foundCount);
			scanf("%d", &choice);
			getchar();

			if (choice < 1 || choice > foundCount) {
				printf(RED"Invalid selection. Please enter a number between 1 and %d.\n"RESET, foundCount);
			}
		} while (choice < 1 || choice > foundCount);

		index = foundIndices[choice - 1];
	}

	char confirmation;
	do {
		printf("Are you sure you want to delete this contact? (y/n): ");
		scanf("%c", &confirmation);// for final confirmation
		getchar();

		if (confirmation != 'y' && confirmation != 'n') {
			printf(RED"Invalid option. Please enter 'y' for yes or 'n' for no.\n"RESET);
		}
	} while (confirmation != 'y' && confirmation != 'n');// run until valid user input

	if (confirmation == 'y') {
		for (int j = index; j < addressBook->contactCount - 1; j++)
	       	{
			addressBook->contacts[j] = addressBook->contacts[j + 1];// shifting will done for decreasing deleting info
		}
		addressBook->contactCount--;// it will decrease contactcount

		printf(GREEN"Contact deleted successfully!\n"RESET);
	} else {
		printf("Deletion canceled.\n");
	}
}

